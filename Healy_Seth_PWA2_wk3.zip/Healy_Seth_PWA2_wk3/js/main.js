                                    //slider start//



jQuery(document).ready(function($){

  var sliderCount= $('#myslider ul li').length;
  var sliderWidth= $('#myslider ul li').width();
  var sliderHeight= $('#myslider ul li').height();
  var sliderUlWidth= sliderCount * sliderWidth;

  $('#myslider').css({ width: sliderWidth, height: sliderHeight});
  $('#myslider ul').css({ width: sliderUlWidth, marginLeft: -sliderWidth});
  $('#myslider ul li:last-child').prependTo('#slider ul');


  console.log(window.location.href);


  function moveLeft(){

    $('#myslider ul').animate({
      left: + sliderWidth
    }, 200, function(){
      $('#myslider ul li:last-child').prependTo('#myslider ul');
      $('#myslider ul').css('left', '');
    });
    };

    function moveRight(){

      $('#myslider ul').animate({
        left: -sliderWidth
      }, 200, function (){
        $('#myslider ul li:first-child').appendTo('#myslider ul');
        $('#myslider ul').css('left', '');
    });
    };  
  
    $('a.control_prev').click(function(){
      moveLeft();
    });

    $('a.control_next').click(function(){
      moveRight();
    });

                                      //Slider stop//


                                      // Accordian start //
                                                                        // Accordian stop //


  

  $('#signinButton').click(function(e){
     e.preventDefault();
    var user =$('#user').val();
    var pass =$('#pass').val();
    console.log("This notifies you if the password is working");
    
    $.ajax({
      url:'xhr/login.php',
      type:'post',
      dataType:'json',
      data:{
        username:user,
        password:pass
      },
      success:function(response){
        console.log("Test User");
        if(response.error){
          alert(response.error);
        } else{
          window.location.assign('admin.html')
        };
      }
    });
  });



$('#register').on('click', function(){
  
  var username= $('#username').val(),
      email= $('#email').val(),
      password= $('#password').val();

  $.ajax({
    url:'xhr/register.php',
    type:'post',
    dataType:'json',
    data:{
      username:username,
      email:email,
      password:password
    },

    success: function(response){
      if (response.error){
        alert(response.error);
      }else{
        window.location.assign('admin.html');
      }
    }
  });
});

$('.projectsbtn').on('click', function(e){
  e.preventDefault();
  window.location.assign('projects.html');
});

$('.addbtn').on('click', function(e){
  e.preventDefault();
  window.location.assign('add.html');
});


$('#addButton').on('click', function(e){
  e.preventDefault();
  var projName =$('#projectName').val(),
  projDesc =$('#projectDescription').val(),
  projDue =$('#projectDueDate').val(),
  projectStatus =$('#projectStatus').val();

  $.ajax({
    url: "xhr/new_project.php",
    type: "post",
    dataType:"json",
    data:{
      projectName: projName,
      projectDescription: projDesc,
      dueDate: projDue,
      status:projectStatus
    },
    success:function(response){
      console.log('testing for success');

      if(response.error){
        alert(response.error);
      } else{
        window.location.assign("projects.html");


      };
    }
  });
});

var projects = function(){

    $.ajax({
      url: 'xhr/get_projects.php',
      type: 'get',
      dataType:'json',
      success: function(response){
        if(response.error){
          console.log(response.error);
        }else{
          console.log('got projects');
          for(var i=0, j=response.projects.length; i<j; i++){
            var result=response.projects[i];

            $(".projects").append(
              '<div style="border:1px solid black">'+
              " Project ID:" + result.id + "<br>" +
              "Project Name: " + result.projectName + "<br>" +
              "Project Description: " + result.projectDescription + "<br>" +
              "Project Due date: " + result.dueDate + "<br>" +
              "Project status: " + result.status + "<br>" +
              '<button class="deletebtn"> Delete </button>'
              +'</div> <br>'
              );
            };

            $('.deletebtn').on('click', function(e){
            console.log('test delete');

              $.ajax({
                url: 'xhr/delete_project.php',
                data:{
                  projectID: result.id
                },
                type: 'POST',
                dataType: 'json',
                success: function(response){
                  console.log('testing for success');

                  if(response.error){
                    alert(response.error);
                  } else{
                    window.location.assign("projects.html");
                  } // if statement
                }// success
              })//ajax
            })//click
          }//else
        }//success
    })//ajax
  }//function
  console.log(window.location);
  if(window.location.href == "http://localhost:8888/Healy_Seth_PWA2_wk3/projects.html"){
    console.log('this is the project page');
    projects();
  };

$('#signOut').click(function(e){
  console.log('logout');
  e.preventDefault();
  $.get('xhr/logout.php', function(){
    window.location.assign('index.html')
  })
});

// var welcomeSound = document.getElementById('welcomeSound');
// var welcomeTxt=document.getElementById('welcomeTxt');
// welcomeTxt.onmouseover=function(){
//  welcomeSound.play();
//  return false;
// };


// welcomeTxt.onmouseout=function(){
//  welcomeSound.pause().delay(1000);
//  console.log("click")
// };


$(function() {
    $( "#projectDueDate" ).datepicker({
      showOn: "button",
      buttonImage: "images/calendar.gif",
      buttonImageOnly: true
    });
  });

$( "#accordion" )
      .accordion({
        header: "> div > h3"
      })
      .sortable({
        axis: "y",
        handle: "h3",
        stop: function( event, ui ) {
          // IE doesn't register the blur when sorting
          // so trigger focusout handlers to remove .ui-state-focus
          ui.item.children( "h3" ).triggerHandler( "focusout" );
        }
      });

});














  